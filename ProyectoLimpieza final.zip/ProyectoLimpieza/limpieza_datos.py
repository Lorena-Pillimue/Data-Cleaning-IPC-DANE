import pandas as pd
import numpy as np

# --- . CARGA DEL ARCHIVO ---
try:
    archivo_entrada = "datos de dtx.xlsx"
    df = pd.read_excel(archivo_entrada, header=[3, 4])
    print(f"Archivo '{archivo_entrada}' cargado exitosamente.")
except FileNotFoundError:
    print(f"Error: No se encontró el archivo '{archivo_entrada}'.")
    exit()

# --- . ARREGLAR COLUMNAS COMBINADAS ---
nuevas_columnas = []
for col in df.columns:
    nivel_1 = str(col[0]).strip()
    nivel_2 = str(col[1]).strip()
    
    if "Unnamed" in nivel_2 or "nan" in nivel_2:
        nombre_final = nivel_1
    else:
        nombre_final = f"{nivel_1} {nivel_2}"
    nuevas_columnas.append(nombre_final)

df.columns = nuevas_columnas

# --- . LIMPIEZA INICIAL Y DE ESPACIOS ---
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

# Convertimos celdas con solo espacios en blanco en NaN reales
df = df.replace(r'^\s*$', np.nan, regex=True)

# Quitar filas completamente vacías
df = df.dropna(how='all')

# --- . RELLENAR AÑOS (ffill) ---
if 'Año' in df.columns:
    df['Año'] = df['Año'].ffill()

def es_fila_valida(row):
    anio = str(row.get('Año', '')).strip()
    mes = str(row.get('Mes', '')).strip().lower()
    
    if "año corrido" in mes or "anual" in mes:
        return True
    
    anio_limpio = anio.replace('.0', '')
    if anio_limpio.isdigit() and len(anio_limpio) == 4:
        return True
    return False

df_limpio = df[df.apply(es_fila_valida, axis=1)].copy()


for col in df_limpio.columns:
    
    if "Variación" in col or "Índice" in col:
        df_limpio[col] = pd.to_numeric(df_limpio[col], errors='coerce')
    
    if col == "Año":
        df_limpio[col] = pd.to_numeric(df_limpio[col], errors='coerce').astype(int)


df_limpio = df_limpio.replace({np.nan: "null"})
# También por si quedaron celdas vacías 
df_limpio = df_limpio.fillna("null")

# --- . GUARDAR RESULTADO FINAL ---
archivo_salida = "datos_dtx_limpios_FINAL.xlsx"

try:
    df_limpio.to_excel(archivo_salida, index=False)
    print(f"---")
    print(f"¡Proceso completado con éxito!")
    print(f"Ahora los espacios vacíos dicen 'null' en: {archivo_salida}")
except PermissionError:
    print(f"---")
    print(f"ERROR: Cierra el Excel '{archivo_salida}' para poder guardar.")