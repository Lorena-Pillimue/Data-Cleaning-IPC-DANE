import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# . CARGAR LOS DATOS LIMPIOS
archivo = "datos_dtx_limpios_FINAL.xlsx"
df = pd.read_excel(archivo)

# . PREPARAR LOS DATOS PARA CÁLCULO
df['Indice_Num'] = pd.to_numeric(df['Índice'], errors='coerce')
datos_validos = df['Indice_Num'].dropna()


# 3. CÁLCULOS ESTADÍSTICOS (Análisis Descriptivo)

print("======= INFORME ESTADÍSTICO DEL IPC =======")
print(f"Media (Promedio): {datos_validos.mean():.2f}")
print(f"Mediana (Mitad):   {datos_validos.median():.2f}")
print(f"Moda (Repetido):  {datos_validos.mode()[0]:.2f}")

print("\n--- MEDIDAS DE DISPERSIÓN ---")
print(f"Rango:               {datos_validos.max() - datos_validos.min():.2f}")
print(f"Desviación Estándar: {datos_validos.std():.2f}")
print(f"Varianza:            {datos_validos.var():.2f}")

# 4. IDENTIFICACIÓN DE OUTLIERS (Valores Atípicos)
Q1 = datos_validos.quantile(0.25)
Q3 = datos_validos.quantile(0.75)
IQR = Q3 - Q1
limite_inf = Q1 - 1.5 * IQR
limite_sup = Q3 + 1.5 * IQR

outliers = datos_validos[(datos_validos < limite_inf) | (datos_validos > limite_sup)]

print("\n--- ANÁLISIS DE OUTLIERS ---")
if not outliers.empty:
    print(f"Se detectaron {len(outliers)} valores fuera de lo común.")
    print(f"Valores detectados: \n{outliers.values}")
else:
    print("Los datos son consistentes: No hay valores atípicos significativos.")


# 5. VISUALIZACIÓN DE LOS DATOS

plt.figure(figsize=(12, 6))

# Caja y Bigotes (Para ver Outliers visualmente)
plt.subplot(1, 2, 1)
sns.boxplot(y=datos_validos, color='lightgreen')
plt.title("Distribución y Outliers (Boxplot)")

# Histograma (Para ver la forma de la distribución)
plt.subplot(1, 2, 2)
sns.histplot(datos_validos, kde=True, color='blue')
plt.title("Histograma de Frecuencias")

plt.tight_layout()
plt.savefig("analisis_grafico_estatistico.png")
print("\n[INFO] Gráfica de análisis guardada como: analisis_grafico_estatistico.png")
plt.show()