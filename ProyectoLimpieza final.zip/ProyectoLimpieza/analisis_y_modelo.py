import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
import numpy as np

# . Cargar datos de la tabla final
archivo = "datos_dtx_limpios_FINAL.xlsx"
df = pd.read_excel(archivo)

# 2. Preparación para Análisis 
# Convertimos a numérico y lo que diga "null" se vuelve NaN automáticamente
df['X'] = pd.to_numeric(df['Año'], errors='coerce')
df['Y'] = pd.to_numeric(df['Índice'], errors='coerce')

df_plot = df.dropna(subset=['X', 'Y']).copy()

df_anual = df_plot.groupby('X')['Y'].mean().reset_index()

# --- GRAFICA: TENDENCIA HISTÓRICA ---
plt.figure(figsize=(10, 5))
sns.lineplot(data=df_anual, x='X', y='Y', marker='o', color='royalblue', linewidth=2)
plt.title("1. Evolución Histórica del IPC (Promedio Anual)", fontsize=14)
plt.xlabel("Año")
plt.ylabel("Índice de Precios")
plt.grid(True, alpha=0.3)
plt.savefig("1_tendencia.png")
print("Gráfico 1 guardado: 1_tendencia.png")

# --- GRAFICA: DISTRIBUCIÓN DE VALORES ---
plt.figure(figsize=(10, 5))
sns.histplot(df_plot['Y'], kde=True, color='orange', bins=20)
plt.title("2. Distribución de los Valores del IPC", fontsize=14)
plt.xlabel("Rango del Índice")
plt.ylabel("Frecuencia")
plt.savefig("2_distribucion.png")
print("Gráfico 2 guardado: 2_distribucion.png")

# --- GRAFICA: REGRESIÓN LINEAL ---
plt.figure(figsize=(10, 5))
sns.regplot(data=df_anual, x='X', y='Y', scatter_kws={'alpha':0.6}, line_kws={'color':'red'})
plt.title("3. Correlación y Tendencia de Regresión", fontsize=14)
plt.xlabel("Año")
plt.ylabel("Índice")
plt.savefig("3_regresion.png")
print("Gráfico 3 guardado: 3_regresion.png")


X_val = df_anual[['X']].values
y_val = df_anual['Y'].values
modelo = LinearRegression().fit(X_val, y_val)


siguiente_anio = int(X_val.max() + 1)
pred = modelo.predict([[siguiente_anio]])

print(f"\n--- RESULTADOS DEL MODELO ---")
print(f"Predicción para el año {siguiente_anio}: {pred[0]:.2f}")
print(f"Precisión del modelo (R2): {modelo.score(X_val, y_val):.2f}")

plt.tight_layout()
plt.show()